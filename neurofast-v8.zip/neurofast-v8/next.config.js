/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    serverActions: {
      // v8 fix: filter out empty string when NEXT_PUBLIC_APP_URL is not set
      allowedOrigins: ["localhost:3000", process.env.NEXT_PUBLIC_APP_URL].filter(Boolean),
    },
  },
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "**.supabase.co" },
      { protocol: "https", hostname: "img.clerk.com" },
    ],
  },
};

module.exports = nextConfig;
